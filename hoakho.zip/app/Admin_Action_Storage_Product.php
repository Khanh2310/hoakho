<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Action_Storage_Product extends Model
{
    //
    protected $table = 'admin_action_storage_product';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
