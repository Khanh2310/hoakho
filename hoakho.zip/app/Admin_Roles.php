<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Roles extends Model
{
    protected $table = 'admin_roles';
    public $timestamps = false;
}
