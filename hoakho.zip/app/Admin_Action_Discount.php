<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Action_Discount extends Model
{
    protected $table = 'admin_action_discount';
    public $timestamps = false;
}
