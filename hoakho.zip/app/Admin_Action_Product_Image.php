<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Action_Product_Image extends Model
{
    protected $table = 'admin_action_product_image';
    public $timestamps = false;
}
