<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Action_Storage extends Model
{
    //
    protected $table = 'admin_action_storage';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
