<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Action_Product_Price extends Model
{
    protected $table = 'admin_action_product_price';
    public $timestamps = false;
}
