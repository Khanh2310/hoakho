<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Action_Unit extends Model
{
    protected $table = 'admin_action_unit';
    public $timestamps = false;
}
