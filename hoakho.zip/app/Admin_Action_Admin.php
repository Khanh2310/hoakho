<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin_Action_Admin extends Model
{
    protected $table = 'admin_action_admin';
    public $timestamps = false;
}
