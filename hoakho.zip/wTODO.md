Khanh{ 
    - admin{
        - delete -> find, filter -> ok
    }
    - product {
        - delete -> find, filter -> ok
    }
    - comment{
        - delete -> filter -> ok
        - accep -> filter -> ok
    }
    - discount {
        -delete -> filter ->ok
    }
}

Kha{ 
    - storage {
        - delete -find, filter
        - update -> find
    }
    - voucher {
        detail -> find, filter
        delete -> find, filter
    }
}



HOST -> voucher -> varchar(50)
